# QuotaMob · Pacote de exportação

Dentro desta pasta/zip encontras tudo o que precisas para reconstruir a app noutra
ferramenta (Google AI Studio) sem perder nada do que já está feito.

## O que vem no pacote

| Caminho | Conteúdo |
|---|---|
| `PROMPT_GOOGLE_AI_STUDIO.md` | Especificação completa da app em forma de prompt, mais os prompts por etapa e os dados de ligação |
| `BASE_DADOS_SUPABASE.sql` | Script único com tabelas, trigger de perfis, políticas de segurança (RLS), funções de conta e buckets — cria a base de dados de raiz |
| `LEIA-ME.md` | Este guia |
| `codigo/` | Todo o código-fonte actual da aplicação (React + Vite), pronto a copiar ou abrir num editor |

## Como usar no Google AI Studio

1. **Base de dados:** cria um projeto novo no Supabase (ou reutiliza o actual, se ainda
   estiver ativo) e cola o `BASE_DADOS_SUPABASE.sql` no SQL Editor. Corre tudo de uma vez.
2. **Administrador:** cria a tua conta na app e corre, no SQL Editor, o `update` final do
   script (está comentado no fim) com o teu número, para ficares tesoureiro.
3. **Autenticação no Supabase:** em Authentication → Sign In / Providers, mantém
   **Email** ligado. As contas usam emails internos `<numero>@quotamob.app`; não é preciso
   enviar emails reais.
4. **AI Studio:** abre `PROMPT_GOOGLE_AI_STUDIO.md` e cola a Parte A como primeiro prompt.
   Se preferires construir por partes, usa os prompts da Parte C, um de cada vez.
5. **Ligação:** confirma o URL e a chave publishable no código gerado. Se mudaste de
   projeto Supabase, substitui-os (ficheiro `src/lib/supabaseConfig.js`, ou o ecrã de
   configuração dentro da app).

## Regras a não esquecer

- A chave **service_role** nunca entra no código do browser. Só a `anon`/publishable.
- O perfil em `motoristas` é criado por **trigger** a partir de `auth.users` — não faças
  INSERT manual depois do registo.
- Comprovativos: só PDF real, entre 10 KB e 2 MB.
- Todas as listas têm de ser paginadas (o Supabase devolve no máximo 1000 linhas) e os
  totais contados no servidor.
- Ao eliminar um motorista, apaga também a conta em `auth.users` (função
  `quotamob_apagar_motorista`), senão o número fica preso para sempre.
