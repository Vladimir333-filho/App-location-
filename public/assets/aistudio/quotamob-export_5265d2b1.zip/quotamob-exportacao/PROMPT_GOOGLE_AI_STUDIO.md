# QuotaMob · Prompt completo para o Google AI Studio

> Este documento reconstrói a especificação da app tal como ela existe hoje.
> Cola a **Parte A** no AI Studio de uma vez, ou usa os prompts por etapa da **Parte C**
> (recomendado: uma etapa de cada vez, testando antes de avançar).

---

## PARTE A · Prompt principal (colar no Google AI Studio)

Cria uma aplicação web **mobile-first** chamada **QuotaMob** para gestão de quotas de
motoristas profissionais em Angola. Interface **só em modo claro**, toda em **português de
Angola**, valores sempre no formato `5.000 Kz`. O objetivo é acabar com o dinheiro vivo:
o motorista vê a sua quota, paga por Multicaixa/IBAN, envia o comprovativo em PDF e o
tesoureiro aprova ou rejeita no painel.

**Stack obrigatória:** React + Vite + Tailwind CSS (se o AI Studio gerar TypeScript, mantém
os mesmos nomes de campos e fluxos), Supabase como base de dados e autenticação. Não usar
bibliotecas de UI que obriguem a servidor próprio. Guardar a sessão no `localStorage`.

### 1. Ligação ao Supabase
- Projeto já existente. URL e chave `anon`/publishable vão num ficheiro de configuração
  (`src/lib/supabaseConfig.js`), com possibilidade de o utilizador as substituir no browser
  (guardadas em `localStorage`).
- **Nunca** usar a chave `service_role` no frontend.
- Todas as chamadas REST passam por um único módulo (`src/lib/supabaseClient.js`) com:
  - injeção automática de `apikey` e `Authorization: Bearer <access_token>`;
  - renovação automática do token quando faltam menos de 60 segundos, com **uma única
    renovação em curso** (o Supabase troca o refresh token a cada uso);
  - **paginação obrigatória** (limite de 1000 linhas por pedido do Supabase), com uma
    função `pedirTudo(tabela, query)` que percorre as páginas até acabar;
  - contagem no servidor com `Prefer: count=exact` e leitura do cabeçalho `content-range`
    (nunca contar linhas carregadas no browser);
  - repetição automática uma vez em caso de falha de rede e mensagem final em português.

### 2. Autenticação por telefone (sem SMS)
- O telefone é convertido em email interno: `9XXXXXXXX@quotamob.app` (só dígitos).
- **Entrar:** email/password no endpoint `/auth/v1/token?grant_type=password`.
  Mensagens: "Número ou palavra-passe incorretos.", "Esta conta ainda não está ativada...".
- **Criar conta:** `/auth/v1/signup` com `data: { nome, telefone }`. O perfil na tabela
  `motoristas` é criado por **trigger no Supabase** — nunca fazer INSERT manual.
- Se o número já existir: a app recupera a conta em vez de falhar. Mensagem:
  "Este número já tem conta criada. Usa 'Recuperar palavra-passe'."
- **Recuperar palavra-passe automática:** função RPC `quotamob_repor_senha(telefone, nome,
  nova_senha)` valida telefone + nome do registo e grava a nova palavra-passe. Se a conta
  de autenticação existir mas o perfil tiver sido apagado, usar
  `quotamob_activar_numero` (reaproveita a conta e recria o perfil).
- **Sair:** chama `/auth/v1/logout` e limpa a sessão local (mesmo sem rede).
- O papel (`role`) vem da tabela `motoristas`: `motorista` ou `admin`. Rotas protegidas:
  motorista só vê as suas quotas; `admin` vê tudo.

### 3. Base de dados (ver `BASE_DADOS_SUPABASE.sql`)
- `motoristas(id, nome, telefone, role, ativo, foto_url, created_at)` — `id` = id de `auth.users`.
- `quotas(id, motorista_id, referencia, valor_kz, vencimento, estado, created_at)` com
  **chave única (motorista_id, referencia)**.
- `pagamentos(id, quota_id, motorista_id, valor_kz, comprovativo_path, estado,
  motivo_rejeicao, created_at)`.
- `auditoria_pagamentos(...)` opcional: a app funciona mesmo que não exista.
- Buckets: `comprovativos` (privado, com links assinados) e `perfis` (público).
- Estados de quota: `pendente`, `em_analise`, `paga`, `atrasada`. Estados de pagamento:
  `em_analise`, `aprovado`, `rejeitado`.
- O estado `atrasada` é **calculado na app**: se a quota não está paga e a data de
  vencimento já passou, mostra "Atrasada" mesmo que o campo diga `pendente`.

### 4. Design
- Paleta em tokens (HSL): azul-escuro principal (`--primary: 214 62% 18%`), fundo
  `214 40% 97%`, verde de sucesso (`158 74% 30%`), vermelho para atraso.
- Tipografia **Manrope** (headings e corpo), cartões com cantos muito arredondados
  (`rounded-3xl`), sombras suaves, botões altos (mínimo 48 px) para dedo.
- Navegação inferior fixa com 3 itens no motorista (Quotas, Histórico, Perfil) e 5 no
  admin (Painel, Aprovações, Motoristas, Quotas, Configurações), respeitando a área segura
  do iPhone (`env(safe-area-inset-bottom)`).
- Sem animações pesadas: uma entrada suave de 350 ms por página.
- Suporta ligações lentas: mostrar esqueletos/spinner e mensagens de erro com
  "Tentar de novo".

### 5. Ecrãs do motorista
1. **Entrar** (`/`): telefone (9 dígitos), palavra-passe, ver/ocultar, "Entrar",
   "Esqueci-me da palavra-passe", "Criar conta". Rodapé com link de WhatsApp para o
   tesoureiro. Mostrar cartão de configuração da ligação ao Supabase se não houver ligação.
2. **Criar conta** (`/criar-conta`): nome, telefone, palavra-passe + confirmar.
   Após registo, entra automaticamente.
3. **Recuperar palavra-passe** (`/recuperar-senha`): telefone + nome do registo + nova
   palavra-passe; repõe automaticamente e entra. Se falhar, oferecer contacto do tesoureiro.
4. **Minhas quotas** (`/quotas`): cartão de destaque com o **total em dívida** e quantas
   quotas estão em atraso; alerta vermelho "Tens X Kz em atraso" com atalho para a mais
   antiga; filtros (Todas, Pendentes, Em análise, Pagas, Atrasadas); lista de cartões com
   referência, vencimento, valor e etiqueta de estado. Cada cartão aberto leva ao pagamento.
5. **Pagar quota** (`/quotas/:id/pagar`): dados de pagamento (número Multicaixa, IBAN,
   titular e nota) com botão de copiar em cada linha; campo do valor pago; upload do
   comprovativo; botão "Enviar comprovativo". Depois de enviar: ecrã de sucesso
   "Comprovativo enviado, aguarda aprovação".
6. **Histórico** (`/historico`): lista de pagamentos do motorista com estado, valor, data
   e motivo quando foi rejeitado. Abre o comprovativo numa nova aba.
7. **Perfil** (`/perfil`): fotografia (upload para o bucket `perfis`), nome, telefone,
   papel, mudar fotografia, sair.

### 6. Ecrãs do tesoureiro (admin)
1. **Painel** (`/admin`): quatro cartões — **Total esperado** (soma de todas as quotas),
   **Total recebido** (soma dos pagamentos aprovados), **Total em atraso** (quotas
   atrasadas) e **Adesão · pagamentos** (contador inteiro: sobe 1 por cada quota paga).
   Alerta de quotas em atraso, atalho "N comprovativos em análise", filtro por período
   (De/Até) e por estado, separadores "Quem pagou"/"Quem deve", exportação **CSV**
   (separador `;`, BOM UTF-8 para abrir no Excel) e botão para **anular** um comprovativo
   aprovado (a quota volta a `pendente` e o motivo fica no histórico do motorista).
2. **Aprovações** (`/admin/aprovacoes`): fila de comprovativos `em_analise`, com nome,
   telefone, referência, valor, data e botão "Ver PDF" (link assinado, nova aba).
   Aprovar → pagamento `aprovado` + quota `paga`. Rejeitar → pede motivo, pagamento
   `rejeitado` + quota volta a `pendente`.
3. **Motoristas** (`/admin/motoristas`): pesquisa por nome/telefone, lista com estado
   ativo/inativo, criar (nome, telefone, palavra-passe, papel) com opção
   **"Guardar e adicionar outro"**, editar, ativar/desativar, repor palavra-passe,
   eliminar com confirmação. Ao eliminar: apagar pagamentos → quotas → perfil → conta de
   autenticação (via RPC), para o número poder voltar a ser registado.
4. **Quotas** (`/admin/quotas`): gerar quotas para todos (ou para os selecionados) com
   referência, valor e vencimento; não duplica quotas já existentes para a mesma
   referência; lista das quotas geradas com possibilidade de apagar em lote.
5. **Configurações** (`/admin/configuracoes`): dados de pagamento (número, IBAN, titular,
   instruções), guardados localmente no dispositivo do tesoureiro; cartões com os scripts
   SQL de reposição de palavra-passe e de fotografias, com botão de copiar e ligação ao
   SQL Editor do Supabase.

### 7. Regras de negócio que não podem ser alteradas
- **Comprovativo:** apenas PDF verdadeiro. Validar extensão `.pdf`, tamanho entre
  **10 KB e 2 MB**, primeiros bytes `%PDF-`, ficheiro terminar em `%%EOF`, e rejeitar
  `/Encrypt` (PDF protegido). Mensagens específicas para cada caso. Validar **duas vezes**:
  no ecrã e antes de enviar.
- **Envio do comprovativo:** guardar em `comprovativos/<id_do_motorista>/<id_quota>-<timestamp>.pdf`,
  criar registo em `pagamentos` com estado `em_analise` e passar a quota a `em_analise`.
- **Aprovar** só muda o pagamento para `aprovado` e a quota para `paga`.
- **Rejeitar** grava `motivo_rejeicao` e devolve a quota a `pendente`.
- **Adesão** é um contador simples (não percentagem): soma das quotas pagas.
- **Nunca** permitir editar o papel (`role`) a partir do perfil do próprio utilizador —
  apenas o tesoureiro o faz no painel.
- Datas em `YYYY-MM-DD`; mostrar em `dd/mm/aaaa`.

### 8. Mensagens e erros
Todas as mensagens em português simples. Exemplos obrigatórios:
- "Não foi possível ligar ao servidor do QuotaMob. Confirma a tua internet e tenta outra vez.
  Se o problema continuar, a base de dados pode estar em pausa no Supabase (plano gratuito)
  — abre o painel do Supabase e reactiva o projeto."
- "Este PDF está vazio ou incompleto. Descarrega outra vez o comprovativo do Multicaixa Express."
- "O PDF tem 3,4 MB. O máximo aceito é 2 MB."
- "Não foi possível guardar a fotografia. Confirma o script das fotografias no Supabase."

### 9. Critérios de aceitação
- Um motorista novo consegue criar conta e ver imediatamente as quotas atribuídas.
- Consegue enviar um PDF válido e vê o estado mudar para "Em análise".
- O tesoureiro vê o comprovativo, abre o PDF e aprova; o motorista vê "Paga".
- Eliminar um motorista liberta o número para um novo registo.
- O painel faz os totais certos com mais de 1000 registos (paginação + count no servidor).
- A app funciona bem num ecrã de 360 px de largura.

---

## PARTE B · Dados de ligação ao Supabase

| Item | Valor |
|---|---|
| URL do projeto | `https://vwcuzpvwzzgnyendjboq.supabase.co` |
| Chave publishable (anon) | `sb_publishable_R8H_V0oTHmJTJ1MF7TbqKg_8YfnhEil` |
| Bucket privado | `comprovativos` |
| Bucket público | `perfis` |
| Email interno | `<9 dígitos>@quotamob.app` |

> A chave `anon`/publishable é pública por desenho — vai no código do browser. A chave
> **service_role** nunca pode sair do servidor.

---

## PARTE C · Prompts por etapa (ordem recomendada)

**Etapa 1 — Base + autenticação**
> Cria o projeto QuotaMob (React + Vite + Tailwind, mobile-first, português de Angola) com
> Supabase. Faz o módulo de ligação (`supabaseClient`) com sessão em localStorage,
> renovação automática de token e paginação de 1000 linhas. Cria os ecrãs Entrar, Criar
> conta e Recuperar palavra-passe, usando telefone convertido em `<numero>@quotamob.app`.
> Perfil e permissões vêm da tabela `motoristas`.

**Etapa 2 — Área do motorista**
> Adiciona as rotas /quotas, /historico e /perfil com navegação inferior fixa. Mostra o
> total em dívida, alerta de atraso, filtros por estado e cartões de quota. O perfil permite
> trocar fotografia (bucket `perfis`) e sair.

**Etapa 3 — Pagamento com comprovativo**
> Cria /quotas/:id/pagar com os dados de pagamento copiáveis e upload de PDF. Valida o PDF
> (extensão, 10 KB a 2 MB, assinatura %PDF-, fim %%EOF, sem /Encrypt). Guarda no bucket
> `comprovativos`, cria o pagamento em análise e passa a quota a em_analise.

**Etapa 4 — Painel do tesoureiro**
> Cria /admin com os quatro cartões (esperado, recebido, em atraso, adesão = quotas pagas),
> filtros por período/estado, separadores Quem pagou/Quem deve, exportação CSV e anulação
> de comprovativo aprovado.

**Etapa 5 — Aprovações e motoristas**
> Cria /admin/aprovacoes (ver PDF em nova aba, aprovar, rejeitar com motivo) e
> /admin/motoristas (criar com "Guardar e adicionar outro", editar, ativar/desativar,
> repor palavra-passe, eliminar apagando também a conta de autenticação).

**Etapa 6 — Geração de quotas e polimento**
> Cria /admin/quotas para gerar quotas em lote sem duplicar a referência por motorista, e
> /admin/configuracoes com dados de pagamento guardados localmente e os scripts SQL.
> Revê todos os estados vazios, de carregamento e de erro em português.
