import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import { SessaoProvider } from '@/lib/sessao';
import AppShell, { ITENS_ADMIN } from '@/components/AppShell';
import { RotaAdmin, RotaMotorista, RotaUtilizador } from '@/components/RotaProtegida';
// Add page imports here
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
import Entrar from '@/pages/Entrar';
import CriarConta from '@/pages/CriarConta';
import RecuperarSenha from '@/pages/RecuperarSenha';
import MinhasQuotas from '@/pages/MinhasQuotas';
import PagarQuota from '@/pages/PagarQuota';
import Historico from '@/pages/Historico';
import Painel from '@/pages/admin/Painel';
import Aprovacoes from '@/pages/admin/Aprovacoes';
import Motoristas from '@/pages/admin/Motoristas';
import GerarQuotas from '@/pages/admin/GerarQuotas';
import Configuracoes from '@/pages/admin/Configuracoes';
import Perfil from '@/pages/Perfil';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <SessaoProvider>
      <Routes>
        {/* Auth routes */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />

        {/* QuotaMob */}
        <Route path="/" element={<Entrar />} />
        <Route path="/criar-conta" element={<CriarConta />} />
        <Route path="/recuperar-senha" element={<RecuperarSenha />} />

        <Route element={<RotaMotorista />}>
          <Route element={<AppShell />}>
            <Route path="/quotas" element={<MinhasQuotas />} />
            <Route path="/historico" element={<Historico />} />
          </Route>
          <Route path="/quotas/:quotaId/pagar" element={<PagarQuota />} />
        </Route>

        <Route element={<RotaAdmin />}>
          <Route element={<AppShell itens={ITENS_ADMIN} mostrarConfig />}>
            <Route path="/admin" element={<Painel />} />
            <Route path="/admin/aprovacoes" element={<Aprovacoes />} />
            <Route path="/admin/motoristas" element={<Motoristas />} />
            <Route path="/admin/quotas" element={<GerarQuotas />} />
            <Route path="/admin/configuracoes" element={<Configuracoes />} />
          </Route>
        </Route>

        <Route element={<RotaUtilizador />}>
          <Route element={<AppShell />}>
            <Route path="/perfil" element={<Perfil />} />
          </Route>
        </Route>

        <Route path="*" element={<PageNotFound />} />
      </Routes>
    </SessaoProvider>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App