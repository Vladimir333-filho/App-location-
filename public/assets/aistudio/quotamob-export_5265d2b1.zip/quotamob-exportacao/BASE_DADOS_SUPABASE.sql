-- ===========================================================================
-- QuotaMob · Base de dados completa (Supabase / PostgreSQL)
-- Corre este ficheiro inteiro, uma única vez, no SQL Editor do Supabase.
-- Ordem: 1) tabelas  2) trigger de perfis  3) políticas RLS  4) funções
--        5) buckets de armazenamento  6) administrador inicial
-- ===========================================================================

create extension if not exists pgcrypto with schema extensions;

-- ---------------------------------------------------------------------------
-- 1) TABELAS
-- ---------------------------------------------------------------------------

-- Perfil de cada pessoa. O id é o mesmo id de auth.users.
create table if not exists public.motoristas (
  id          uuid primary key references auth.users(id) on delete cascade,
  nome        text not null default 'Motorista',
  telefone    text unique,
  role        text not null default 'motorista',   -- 'motorista' | 'admin'
  ativo       boolean not null default true,
  foto_url    text,
  created_at  timestamptz not null default now()
);

-- Quotas cobradas a cada motorista.
create table if not exists public.quotas (
  id            uuid primary key default gen_random_uuid(),
  motorista_id  uuid not null references public.motoristas(id) on delete cascade,
  referencia    text not null,                      -- ex.: 'Novembro 2026 · Semana 1'
  valor_kz      numeric(12,2) not null default 0,
  vencimento    date,
  estado        text not null default 'pendente'
                check (estado in ('pendente','em_analise','paga','atrasada')),
  created_at    timestamptz not null default now(),
  constraint quotas_motorista_referencia_uk unique (motorista_id, referencia)
);

-- Comprovativos enviados pelos motoristas.
create table if not exists public.pagamentos (
  id                 uuid primary key default gen_random_uuid(),
  quota_id           uuid references public.quotas(id) on delete cascade,
  motorista_id       uuid not null references public.motoristas(id) on delete cascade,
  valor_kz           numeric(12,2) not null default 0,
  comprovativo_path  text,                          -- caminho no bucket 'comprovativos'
  estado             text not null default 'em_analise'
                     check (estado in ('em_analise','aprovado','rejeitado')),
  motivo_rejeicao    text,
  created_at         timestamptz not null default now()
);

-- Histórico opcional (a app tolera a ausência desta tabela).
create table if not exists public.auditoria_pagamentos (
  id            uuid primary key default gen_random_uuid(),
  pagamento_id  uuid references public.pagamentos(id) on delete cascade,
  acao          text,
  detalhe       text,
  criado_por    uuid,
  created_at    timestamptz not null default now()
);

-- Índices: o painel conta e filtra por estado e por motorista.
create index if not exists quotas_motorista_idx      on public.quotas (motorista_id);
create index if not exists quotas_estado_idx         on public.quotas (estado);
create index if not exists quotas_referencia_idx     on public.quotas (referencia);
create index if not exists pagamentos_motorista_idx  on public.pagamentos (motorista_id);
create index if not exists pagamentos_quota_idx      on public.pagamentos (quota_id);
create index if not exists pagamentos_estado_idx     on public.pagamentos (estado);
create index if not exists auditoria_pagamento_idx   on public.auditoria_pagamentos (pagamento_id);

-- ---------------------------------------------------------------------------
-- 2) TRIGGER: cada nova conta de autenticação ganha perfil automaticamente
--    (nunca fazer INSERT manual em motoristas depois do registo)
-- ---------------------------------------------------------------------------

create or replace function public.quotamob_novo_perfil()
returns trigger
language plpgsql
security definer
set search_path = public, auth
as $$
begin
  insert into public.motoristas (id, nome, telefone, role, ativo)
  values (
    new.id,
    coalesce(nullif(trim(new.raw_user_meta_data->>'nome'), ''), 'Motorista'),
    regexp_replace(
      coalesce(new.raw_user_meta_data->>'telefone', split_part(new.email, '@', 1)),
      '\D', '', 'g'
    ),
    'motorista',
    true
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists quotamob_criar_perfil on auth.users;
create trigger quotamob_criar_perfil
after insert on auth.users
for each row execute function public.quotamob_novo_perfil();

-- ---------------------------------------------------------------------------
-- 3) SEGURANÇA (RLS)
-- ---------------------------------------------------------------------------

create or replace function public.quotamob_eh_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.motoristas m
     where m.id = auth.uid()
       and lower(coalesce(m.role, '')) like '%admin%'
  );
$$;

grant execute on function public.quotamob_eh_admin() to anon, authenticated;

alter table public.motoristas            enable row level security;
alter table public.quotas                enable row level security;
alter table public.pagamentos            enable row level security;
alter table public.auditoria_pagamentos  enable row level security;

-- MOTORISTAS: cada um vê o seu perfil; o tesoureiro vê todos.
drop policy if exists "motoristas leitura"  on public.motoristas;
create policy "motoristas leitura" on public.motoristas
  for select to authenticated
  using (id = auth.uid() or public.quotamob_eh_admin());

drop policy if exists "motoristas criacao"  on public.motoristas;
create policy "motoristas criacao" on public.motoristas
  for insert to authenticated
  with check (public.quotamob_eh_admin());

drop policy if exists "motoristas alteracao" on public.motoristas;
create policy "motoristas alteracao" on public.motoristas
  for update to authenticated
  using (public.quotamob_eh_admin())
  with check (public.quotamob_eh_admin());

drop policy if exists "motoristas remocao"   on public.motoristas;
create policy "motoristas remocao" on public.motoristas
  for delete to authenticated
  using (public.quotamob_eh_admin());

-- QUOTAS: o motorista vê as suas; só o tesoureiro cria, altera e apaga.
drop policy if exists "quotas leitura"  on public.quotas;
create policy "quotas leitura" on public.quotas
  for select to authenticated
  using (motorista_id = auth.uid() or public.quotamob_eh_admin());

drop policy if exists "quotas criacao"  on public.quotas;
create policy "quotas criacao" on public.quotas
  for insert to authenticated
  with check (public.quotamob_eh_admin());

drop policy if exists "quotas alteracao" on public.quotas;
create policy "quotas alteracao" on public.quotas
  for update to authenticated
  using (public.quotamob_eh_admin())
  with check (public.quotamob_eh_admin());

drop policy if exists "quotas remocao"   on public.quotas;
create policy "quotas remocao" on public.quotas
  for delete to authenticated
  using (public.quotamob_eh_admin());

-- PAGAMENTOS: o motorista vê e envia os seus; o tesoureiro aprova, rejeita e apaga.
drop policy if exists "pagamentos leitura"  on public.pagamentos;
create policy "pagamentos leitura" on public.pagamentos
  for select to authenticated
  using (motorista_id = auth.uid() or public.quotamob_eh_admin());

drop policy if exists "pagamentos criacao"  on public.pagamentos;
create policy "pagamentos criacao" on public.pagamentos
  for insert to authenticated
  with check (motorista_id = auth.uid() or public.quotamob_eh_admin());

drop policy if exists "pagamentos alteracao" on public.pagamentos;
create policy "pagamentos alteracao" on public.pagamentos
  for update to authenticated
  using (public.quotamob_eh_admin())
  with check (public.quotamob_eh_admin());

drop policy if exists "pagamentos remocao"   on public.pagamentos;
create policy "pagamentos remocao" on public.pagamentos
  for delete to authenticated
  using (public.quotamob_eh_admin());

-- AUDITORIA: só o tesoureiro.
drop policy if exists "auditoria leitura"  on public.auditoria_pagamentos;
create policy "auditoria leitura" on public.auditoria_pagamentos
  for select to authenticated using (public.quotamob_eh_admin());

drop policy if exists "auditoria criacao"  on public.auditoria_pagamentos;
create policy "auditoria criacao" on public.auditoria_pagamentos
  for insert to authenticated with check (public.quotamob_eh_admin());

drop policy if exists "auditoria remocao"  on public.auditoria_pagamentos;
create policy "auditoria remocao" on public.auditoria_pagamentos
  for delete to authenticated using (public.quotamob_eh_admin());

grant select, insert, update, delete on public.motoristas, public.quotas,
  public.pagamentos, public.auditoria_pagamentos to authenticated;

-- ---------------------------------------------------------------------------
-- 4) FUNÇÕES DE CONTA (reposição de palavras-passe e contas órfãs)
--    O telefone é transformado em email interno: 9XXXXXXXX@quotamob.app
-- ---------------------------------------------------------------------------

create or replace function public.quotamob_email(p_telefone text)
returns text language sql immutable as $$
  select regexp_replace(coalesce(p_telefone, ''), '\D', '', 'g') || '@quotamob.app';
$$;

-- Tesoureiro define a palavra-passe de um número que já existe na autenticação.
create or replace function public.quotamob_admin_definir_senha(p_telefone text, p_senha text)
returns uuid
language plpgsql security definer set search_path = public, extensions, auth
as $$
declare
  v_email text;
  v_id uuid;
begin
  if not public.quotamob_eh_admin() then
    raise exception 'Só o tesoureiro pode repor palavras-passe.';
  end if;

  if length(coalesce(p_senha, '')) < 6 then
    raise exception 'A palavra-passe precisa de pelo menos 6 caracteres.';
  end if;

  v_email := public.quotamob_email(p_telefone);

  select u.id into v_id from auth.users u where lower(u.email) = lower(v_email) limit 1;
  if v_id is null then
    raise exception 'NÃO_EXISTE';
  end if;

  update auth.users
     set encrypted_password = crypt(p_senha, gen_salt('bf')),
         email_confirmed_at = coalesce(email_confirmed_at, now()),
         updated_at = now()
   where id = v_id;

  return v_id;
end;
$$;

grant execute on function public.quotamob_admin_definir_senha(text, text) to authenticated;

-- Motorista repõe sozinho, confirmando telefone + nome do registo.
create or replace function public.quotamob_repor_senha(p_telefone text, p_nome text, p_nova text)
returns boolean
language plpgsql security definer set search_path = public, extensions, auth
as $$
declare
  v_tel text;
  v_email text;
  v_id uuid;
  v_nome text;
begin
  v_tel := regexp_replace(coalesce(p_telefone, ''), '\D', '', 'g');

  if length(v_tel) <> 9 then
    raise exception 'Escreve os 9 dígitos do teu número de telefone.';
  end if;

  if length(coalesce(p_nova, '')) < 6 then
    raise exception 'A nova palavra-passe precisa de pelo menos 6 caracteres.';
  end if;

  select m.nome into v_nome from public.motoristas m
   where regexp_replace(coalesce(m.telefone, ''), '\D', '', 'g') = v_tel
   limit 1;

  if v_nome is null then
    raise exception 'Este número não está registado. Fala com o tesoureiro.';
  end if;

  if lower(trim(v_nome)) <> lower(trim(coalesce(p_nome, ''))) then
    raise exception 'O nome não corresponde ao registo deste número.';
  end if;

  v_email := public.quotamob_email(v_tel);

  select u.id into v_id from auth.users u where lower(u.email) = lower(v_email) limit 1;
  if v_id is null then
    raise exception 'A conta deste número não existe. Pede ao tesoureiro para a criar outra vez.';
  end if;

  update auth.users
     set encrypted_password = crypt(p_nova, gen_salt('bf')),
         email_confirmed_at = coalesce(email_confirmed_at, now()),
         updated_at = now()
   where id = v_id;

  return true;
end;
$$;

grant execute on function public.quotamob_repor_senha(text, text, text) to anon, authenticated;

-- Tesoureiro apaga a conta de autenticação de um motorista eliminado
-- (sem isto o número fica preso e nunca mais pode ser registado).
create or replace function public.quotamob_apagar_motorista(p_id uuid)
returns boolean
language plpgsql security definer set search_path = public, auth
as $$
begin
  if not public.quotamob_eh_admin() then
    raise exception 'Só o tesoureiro pode apagar contas.';
  end if;

  delete from auth.users where id = p_id;
  return true;
end;
$$;

grant execute on function public.quotamob_apagar_motorista(uuid) to authenticated;

-- Motorista assume um número que ficou com conta de autenticação mas sem perfil.
create or replace function public.quotamob_activar_numero(p_telefone text, p_nome text, p_senha text)
returns boolean
language plpgsql security definer set search_path = public, extensions, auth
as $$
declare
  v_tel text;
  v_email text;
  v_id uuid;
begin
  v_tel := regexp_replace(coalesce(p_telefone, ''), '\D', '', 'g');
  v_email := public.quotamob_email(v_tel);

  if length(coalesce(p_senha, '')) < 6 then
    raise exception 'A palavra-passe precisa de pelo menos 6 caracteres.';
  end if;

  if exists (
    select 1 from public.motoristas m
     where regexp_replace(coalesce(m.telefone, ''), '\D', '', 'g') = v_tel
  ) then
    raise exception 'Este número já está registado. Fala com o tesoureiro.';
  end if;

  select u.id into v_id from auth.users u where lower(u.email) = lower(v_email) limit 1;
  if v_id is null then
    raise exception 'Este número ainda não tem conta. Usa "Criar conta".';
  end if;

  update auth.users
     set encrypted_password = crypt(p_senha, gen_salt('bf')),
         email_confirmed_at = coalesce(email_confirmed_at, now()),
         updated_at = now()
   where id = v_id;

  insert into public.motoristas (id, nome, telefone, role, ativo)
  values (v_id, coalesce(nullif(trim(coalesce(p_nome, '')), ''), 'Motorista'), v_tel, 'motorista', true)
  on conflict (id) do update
    set nome = excluded.nome,
        telefone = excluded.telefone,
        ativo = true;

  return true;
end;
$$;

grant execute on function public.quotamob_activar_numero(text, text, text) to anon, authenticated;

-- ---------------------------------------------------------------------------
-- 5) ARMAZENAMENTO (Storage)
--    comprovativos -> privado (PDF, 10 KB a 2 MB)
--    perfis        -> público (fotografia de perfil)
-- ---------------------------------------------------------------------------

insert into storage.buckets (id, name, public) values ('comprovativos', 'comprovativos', false)
  on conflict (id) do update set public = false;

insert into storage.buckets (id, name, public) values ('perfis', 'perfis', true)
  on conflict (id) do update set public = true;

drop policy if exists "comprovativos leitura" on storage.objects;
create policy "comprovativos leitura" on storage.objects
  for select to authenticated
  using (bucket_id = 'comprovativos' and (
    (storage.foldername(name))[1] = auth.uid()::text or public.quotamob_eh_admin()
  ));

drop policy if exists "comprovativos envio" on storage.objects;
create policy "comprovativos envio" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'comprovativos' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "comprovativos remocao" on storage.objects;
create policy "comprovativos remocao" on storage.objects
  for delete to authenticated
  using (bucket_id = 'comprovativos' and public.quotamob_eh_admin());

drop policy if exists "perfis leitura" on storage.objects;
create policy "perfis leitura" on storage.objects
  for select using (bucket_id = 'perfis');

drop policy if exists "perfis escrita" on storage.objects;
create policy "perfis escrita" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'perfis' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "perfis atualizacao" on storage.objects;
create policy "perfis atualizacao" on storage.objects
  for update to authenticated
  using (bucket_id = 'perfis' and (storage.foldername(name))[1] = auth.uid()::text);

-- Cada conta só muda a sua própria fotografia (nunca o papel nem o nome).
create or replace function public.quotamob_definir_foto(p_url text)
returns void
language plpgsql security definer set search_path = public
as $$
begin
  if auth.uid() is null then
    raise exception 'Sem sessão.';
  end if;

  update public.motoristas set foto_url = p_url where id = auth.uid();

  if not found then
    raise exception 'Perfil não encontrado para esta conta.';
  end if;
end;
$$;

grant execute on function public.quotamob_definir_foto(text) to authenticated;

-- ---------------------------------------------------------------------------
-- 6) ADMINISTRADOR INICIAL
--    Depois de criares a TUA conta na app (Criar conta), corre o UPDATE abaixo
--    com o teu número para ficares tesoureiro.
-- ---------------------------------------------------------------------------

-- update public.motoristas set role = 'admin' where regexp_replace(telefone, '\D', '', 'g') = '900000000';